from django.apps import AppConfig


class RecipeappConfig(AppConfig):
    name = 'recipeapp'
